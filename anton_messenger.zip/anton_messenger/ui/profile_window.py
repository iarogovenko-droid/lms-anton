# ui/profile_window.py
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QFileDialog, QHBoxLayout
)
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtGui import QFont
from config import load_profile, save_profile

class ProfileWindow(QDialog):
    profile_updated = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Профиль")
        self.setFixedSize(320, 200)
        self.apply_styles()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        self.profile = load_profile()

        # Никнейм
        layout.addWidget(QLabel("Никнейм:"))
        self.nick_input = QLineEdit(self.profile["nickname"])
        self.nick_input.setObjectName("profileInput")
        layout.addWidget(self.nick_input)

        # Аватар
        layout.addWidget(QLabel("Аватар:"))
        avatar_layout = QHBoxLayout()
        self.avatar_label = QLabel(self.profile['avatar'] or "не задан")
        self.avatar_label.setWordWrap(True)
        avatar_layout.addWidget(self.avatar_label)

        btn_avatar = QPushButton("Загрузить")
        btn_avatar.setObjectName("avatarBtn")
        btn_avatar.clicked.connect(self.select_avatar)
        avatar_layout.addWidget(btn_avatar)
        layout.addLayout(avatar_layout)

        # Кнопка сохранения
        save_btn = QPushButton("Сохранить профиль")
        save_btn.setObjectName("saveBtn")
        save_btn.clicked.connect(self.save_profile)
        layout.addWidget(save_btn)

    def apply_styles(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e2e;
                color: #cdd6f4;
                font-family: "Segoe UI", Arial, sans-serif;
            }
            QLabel {
                font-size: 13px;
                color: #cdd6f4;
            }
            QLineEdit#profileInput {
                background-color: #181825;
                border: 1px solid #313244;
                border-radius: 6px;
                padding: 6px;
                color: #cdd6f4;
                font-size: 13px;
            }
            QPushButton#avatarBtn, QPushButton#saveBtn {
                background-color: #89b4fa;
                color: #1e1e2e;
                border: none;
                border-radius: 6px;
                padding: 6px;
                font-weight: bold;
            }
            QPushButton#avatarBtn:hover, QPushButton#saveBtn:hover {
                background-color: #74a7f9;
            }
        """)

    def select_avatar(self):
        file, _ = QFileDialog.getOpenFileName(
            self, "Выберите изображение", "", "Images (*.png *.jpg *.jpeg *.bmp)"
        )
        if file:
            self.avatar_path = file
            self.avatar_label.setText(file.split("/")[-1])  # только имя файла

    def save_profile(self):
        data = {
            "nickname": self.nick_input.text().strip() or self.profile["nickname"],
            "avatar": getattr(self, 'avatar_path', self.profile["avatar"])
        }
        save_profile(data)
        self.profile_updated.emit()
        self.accept()