import json
import socket
import random
import string
from pathlib import Path

DATA_DIR = Path.home() / ".anton"
DATA_DIR.mkdir(exist_ok=True)

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def get_network_id():
    ip = get_local_ip()
    return ".".join(ip.split(".")[:3])

def generate_random_nickname(length=7):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def load_profile():
    profile_path = DATA_DIR / "profile.json"
    if profile_path.exists():
        with open(profile_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {"nickname": generate_random_nickname(), "avatar": None}
        save_profile(data)
    data["ip"] = get_local_ip()
    return data

def save_profile(data):
    profile_path = DATA_DIR / "profile.json"
    with open(profile_path, "w", encoding="utf-8") as f:
        json.dump({k: v for k, v in data.items() if k != "ip"}, f, ensure_ascii=False, indent=2)

def load_chats():
    net_id = get_network_id()
    chats_file = DATA_DIR / f"chats_{net_id.replace('.', '_')}.json"
    if chats_file.exists():
        with open(chats_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_chats(chats):
    net_id = get_network_id()
    chats_file = DATA_DIR / f"chats_{net_id.replace('.', '_')}.json"
    with open(chats_file, "w", encoding="utf-8") as f:
        json.dump(chats, f, ensure_ascii=False, indent=2)