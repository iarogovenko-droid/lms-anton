# main.py
import sys
import threading
from PyQt6.QtWidgets import QApplication
from ui.main_window import MainWindow
from server import start_server

if __name__ == "__main__":
    # Запуск Flask-сервера в фоновом потоке
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()

    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())