# server.py
from flask import Flask, request, jsonify
import threading
from config import DATA_DIR

app = Flask(__name__)

# Хранилище сообщений: { "192.168.1.10": [ {...}, ... ] }
messages = {}

@app.route("/info", methods=["GET"])
def get_info():
    from config import load_profile
    profile = load_profile()
    return jsonify({
        "nickname": profile["nickname"],
        "avatar": profile["avatar"]
    })

@app.route("/send", methods=["POST"])
def receive_message():
    sender_ip = request.remote_addr
    data = request.json or {}
    text = data.get("text", "").strip()
    
    if not text:
        return jsonify({"status": "error", "msg": "empty"}), 400

    if sender_ip not in messages:
        messages[sender_ip] = []
    
    messages[sender_ip].append({
        "sender": sender_ip,
        "text": text,
        "type": "text"
    })
    
    return jsonify({"status": "ok"})

@app.route("/messages/<ip>", methods=["GET"])
def get_messages(ip):
    msgs = messages.get(ip, [])
    return jsonify(msgs)

def start_server(port=5000):
    app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)