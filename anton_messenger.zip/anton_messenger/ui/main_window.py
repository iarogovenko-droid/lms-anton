# ui/main_window.py
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QListWidget,
    QTextEdit, QPushButton, QLineEdit, QMessageBox, QInputDialog,
    QLabel, QFrame, QToolButton
)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QRect, QEasingCurve
from PyQt6.QtGui import QFont, QIcon, QPixmap
from ui.profile_window import ProfileWindow
from config import load_profile, load_chats, save_chats, get_local_ip
import requests
import os

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Антон — Локальный мессенджер")
        self.resize(800, 600)

        self.profile = load_profile()
        self.chats = load_chats()
        self.current_chat = None
        self.menu_width = 280  # ширина бокового меню
        self.is_menu_visible = False

        # Центральный виджет
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # === Верхняя панель ===
        top_bar = QWidget()
        top_bar.setFixedHeight(50)
        top_bar.setObjectName("topBar")
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(10, 0, 10, 0)

        # Кнопка "гамбургер"
        self.menu_btn = QToolButton()
        self.menu_btn.setText("☰")
        self.menu_btn.setObjectName("menuBtn")
        self.menu_btn.clicked.connect(self.toggle_menu)
        top_layout.addWidget(self.menu_btn, alignment=Qt.AlignmentFlag.AlignLeft)

        # Заголовок (можно оставить пустым или добавить "Чаты")
        title = QLabel("Антон")
        title.setObjectName("title")
        top_layout.addWidget(title, alignment=Qt.AlignmentFlag.AlignCenter)

        # Кнопка "+"
        self.add_btn = QPushButton("+")
        self.add_btn.setObjectName("addBtn")
        self.add_btn.setFixedSize(36, 36)
        self.add_btn.clicked.connect(self.add_contact)
        top_layout.addWidget(self.add_btn, alignment=Qt.AlignmentFlag.AlignRight)

        main_layout.addWidget(top_bar)

        # === Список чатов + поле ввода ===
        chat_widget = QWidget()
        chat_layout = QVBoxLayout(chat_widget)
        chat_layout.setContentsMargins(10, 10, 10, 10)
        chat_layout.setSpacing(8)

        self.chat_list = QListWidget()
        self.chat_list.setObjectName("chatList")
        self.chat_list.itemClicked.connect(self.select_chat)
        chat_layout.addWidget(self.chat_list)

        self.message_area = QTextEdit()
        self.message_area.setReadOnly(True)
        self.message_area.setObjectName("messageArea")
        chat_layout.addWidget(self.message_area)

        input_layout = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setObjectName("inputField")
        self.input_field.setPlaceholderText("Сообщение...")
        self.send_btn = QPushButton("➤")
        self.send_btn.setObjectName("sendBtn")
        self.send_btn.setFixedWidth(50)
        self.send_btn.clicked.connect(self.send_message)
        self.input_field.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.input_field)
        input_layout.addWidget(self.send_btn)
        chat_layout.addLayout(input_layout)

        main_layout.addWidget(chat_widget)

        # === Боковое меню (профиль) ===
        self.side_menu = QFrame()
        self.side_menu.setFixedWidth(self.menu_width)
        self.side_menu.setObjectName("sideMenu")
        self.side_menu.move(-self.menu_width, 0)  # изначально скрыто слева
        self.side_menu.setParent(self)
        self.side_menu.raise_()

        menu_layout = QVBoxLayout(self.side_menu)
        menu_layout.setContentsMargins(20, 60, 20, 20)
        menu_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # Аватар
        self.avatar_label = QLabel()
        self.avatar_label.setFixedSize(100, 100)
        self.avatar_label.setObjectName("bigAvatar")
        self.avatar_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        menu_layout.addWidget(self.avatar_label, alignment=Qt.AlignmentFlag.AlignCenter)

        # Ник
        self.nick_label = QLabel()
        self.nick_label.setObjectName("menuNick")
        self.nick_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        menu_layout.addWidget(self.nick_label)

        # IP
        self.ip_label = QLabel()
        self.ip_label.setObjectName("menuIp")
        self.ip_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        menu_layout.addWidget(self.ip_label)

        menu_layout.addStretch()

        # Кнопка "Настройки профиля"
        profile_btn = QPushButton("Настроить профиль")
        profile_btn.setObjectName("profileBtn")
        profile_btn.clicked.connect(self.open_profile)
        menu_layout.addWidget(profile_btn)

        self.update_profile_display()
        self.update_chat_list()
        self.start_message_polling()
        self.apply_styles()

    def apply_styles(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #1e1e2e;
                color: #cdd6f4;
                font-family: "Segoe UI", Arial, sans-serif;
            }
            #topBar {
                background-color: #232333;
                border-bottom: 1px solid #313244;
            }
            #menuBtn {
                font-size: 24px;
                color: #cdd6f4;
                border: none;
                background: transparent;
                width: 40px;
                height: 40px;
            }
            #menuBtn:hover {
                color: #89b4fa;
            }
            #title {
                font-size: 18px;
                font-weight: bold;
                color: #cdd6f4;
            }
            #addBtn {
                background-color: #89b4fa;
                color: #1e1e2e;
                border: none;
                border-radius: 18px;
                font-size: 20px;
                font-weight: bold;
                width: 36px;
                height: 36px;
            }
            #addBtn:hover {
                background-color: #74a7f9;
            }
            #chatList {
                background-color: #181825;
                border: none;
                border-radius: 8px;
                padding: 4px;
                color: #cdd6f4;
            }
            #chatList::item {
                padding: 12px;
                border-radius: 8px;
            }
            #chatList::item:selected {
                background-color: #89b4fa;
                color: #1e1e2e;
                font-weight: bold;
            }
            #messageArea {
                background-color: #11111b;
                border: 1px solid #313244;
                border-radius: 12px;
                padding: 12px;
                color: #cdd6f4;
                font-size: 13px;
            }
            #inputField {
                background-color: #181825;
                border: 1px solid #313244;
                border-radius: 20px;
                padding: 10px 16px;
                color: #cdd6f4;
                font-size: 13px;
            }
            #inputField:focus {
                border: 1px solid #89b4fa;
            }
            #sendBtn {
                background-color: #89b4fa;
                color: #1e1e2e;
                border: none;
                border-radius: 20px;
                font-weight: bold;
                font-size: 16px;
            }
            #sendBtn:hover {
                background-color: #74a7f9;
            }

            /* Боковое меню */
            #sideMenu {
                background-color: #181825;
                border-right: 1px solid #313244;
            }
            #bigAvatar {
                background-color: #313244;
                border-radius: 50px;
                font-size: 48px;
                color: #89b4fa;
                border: 2px solid #89b4fa;
            }
            #menuNick {
                font-size: 18px;
                font-weight: bold;
                margin-top: 12px;
                color: #cdd6f4;
            }
            #menuIp {
                font-size: 14px;
                color: #a6adc8;
                margin-bottom: 20px;
            }
            #profileBtn {
                background-color: #89b4fa;
                color: #1e1e2e;
                border: none;
                border-radius: 6px;
                padding: 8px;
                font-weight: bold;
                margin-top: 20px;
            }
            #profileBtn:hover {
                background-color: #74a7f9;
            }
        """)

    def update_profile_display(self):
        self.nick_label.setText(self.profile["nickname"])
        self.ip_label.setText(f"IP: {get_local_ip()}")
        # Пока аватар — текст, но можно загрузить изображение
        self.avatar_label.setText("👤")

    def toggle_menu(self):
        if self.is_menu_visible:
            self.hide_menu()
        else:
            self.show_menu()

    def show_menu(self):
        self.is_menu_visible = True
        self.anim = QPropertyAnimation(self.side_menu, b"geometry")
        self.anim.setDuration(250)
        self.anim.setStartValue(QRect(-self.menu_width, 0, self.menu_width, self.height()))
        self.anim.setEndValue(QRect(0, 0, self.menu_width, self.height()))
        self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.anim.start()

    def hide_menu(self):
        self.is_menu_visible = False
        self.anim = QPropertyAnimation(self.side_menu, b"geometry")
        self.anim.setDuration(250)
        self.anim.setStartValue(QRect(0, 0, self.menu_width, self.height()))
        self.anim.setEndValue(QRect(-self.menu_width, 0, self.menu_width, self.height()))
        self.anim.setEasingCurve(QEasingCurve.Type.InCubic)
        self.anim.start()

    def resizeEvent(self, event):
        if self.side_menu:
            self.side_menu.setFixedHeight(self.height())
        super().resizeEvent(event)

    # --- Остальные методы без изменений ---
    def open_profile(self):
        self.hide_menu()  # закрываем меню при открытии окна
        self.profile_window = ProfileWindow()
        self.profile_window.profile_updated.connect(self.on_profile_update)
        self.profile_window.show()

    def on_profile_update(self):
        self.profile = load_profile()
        self.update_profile_display()

    def update_chat_list(self):
        self.chat_list.clear()
        for ip, data in self.chats.items():
            name = data.get("nickname", ip)
            self.chat_list.addItem(f"{name} ({ip})")

    def add_contact(self):
        ip, ok = QInputDialog.getText(self, "Добавить контакт", "Введите IP-адрес:")
        if not ok or not ip.strip():
            return
        ip = ip.strip()
        try:
            resp = requests.get(f"http://{ip}:5000/info", timeout=3)
            if resp.status_code == 200:
                info = resp.json()
                nickname = info.get("nickname", ip)
                self.chats[ip] = {"nickname": nickname, "avatar": info.get("avatar")}
                save_chats(self.chats)
                self.update_chat_list()
                QMessageBox.information(self, "Успех", f"Контакт {nickname} добавлен!")
            else:
                raise Exception("No response")
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось подключиться к {ip}\n{e}")

    def select_chat(self, item):
        full_text = item.text()
        if "(" in full_text and full_text.endswith(")"):
            self.current_chat = full_text.split("(")[-1][:-1]
        else:
            self.current_chat = full_text
        self.load_messages()

    def load_messages(self):
        if not self.current_chat:
            return
        try:
            local_ip = get_local_ip()
            resp = requests.get(f"http://{self.current_chat}:5000/messages/{local_ip}", timeout=3)
            if resp.status_code == 200:
                msgs = resp.json()
                text = "\n".join([f"{m['sender']}: {m['text']}" for m in msgs])
                self.message_area.setPlainText(text)
                self.message_area.verticalScrollBar().setValue(
                    self.message_area.verticalScrollBar().maximum()
                )
        except:
            self.message_area.setPlainText("[Нет подключения к собеседнику]")

    def send_message(self):
        if not self.current_chat:
            QMessageBox.warning(self, "Ошибка", "Выберите чат!")
            return
        text = self.input_field.text().strip()
        if not text:
            return
        try:
            requests.post(
                f"http://{self.current_chat}:5000/send",
                json={"text": text},
                timeout=3
            )
            self.input_field.clear()
            self.load_messages()
        except Exception as e:
            QMessageBox.warning(self, "Ошибка отправки", str(e))

    def start_message_polling(self):
        self.timer = QTimer()
        self.timer.timeout.connect(self.load_messages)
        self.timer.start(3000)